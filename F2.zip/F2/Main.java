package F2;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Main extends JFrame {
	private BufferedImage image;
	public Main() {
		try {
			image = ImageIO.read(new File("universe.jpg"));
			// Set your Image Here.
			this.setContentPane(new JLabel(new ImageIcon(image)));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// JFrame Properties
		this.setSize(400,620);
		this.setLayout(new FlowLayout());
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setTitle("PC GAME");
		this.setVisible(true);

	}
	public static void main(String[] args){
		Main bg = new Main();
		Spaceship spaceships = new Spaceship();
		bg.getContentPane().setLayout(new BorderLayout());
		bg.getContentPane().add(spaceships);
	}
}